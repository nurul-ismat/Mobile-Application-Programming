package com.example.scbookapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
