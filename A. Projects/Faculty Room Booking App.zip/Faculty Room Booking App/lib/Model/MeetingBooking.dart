class MeetingBooking {
  final String selectedBookingdate;
  final String selectedRoom;
  final String selectedTimeSlot;

  MeetingBooking(
      {this.selectedBookingdate, this.selectedRoom, this.selectedTimeSlot});
}
