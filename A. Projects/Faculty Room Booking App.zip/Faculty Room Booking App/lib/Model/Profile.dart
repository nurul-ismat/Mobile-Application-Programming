class Profile {
  final String username;
  final String fullname;
  final String contact;

  Profile({this.username, this.fullname, this.contact});
}
