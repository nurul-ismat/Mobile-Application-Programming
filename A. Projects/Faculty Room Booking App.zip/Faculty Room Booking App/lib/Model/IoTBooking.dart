class IoTBooking {
  final String selectedBookingdate;
  final String selectedRoom;
  final String selectedTimeSlot;

  IoTBooking(
      {this.selectedBookingdate, this.selectedRoom, this.selectedTimeSlot});
}
