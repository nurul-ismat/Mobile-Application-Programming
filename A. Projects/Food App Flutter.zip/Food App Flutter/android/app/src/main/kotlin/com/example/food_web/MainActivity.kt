package com.example.food_web

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
