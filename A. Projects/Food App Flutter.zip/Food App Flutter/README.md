# Flutter Web - Food App - Flutter UI

## [Watch it on YouTube](https://youtu.be/E6fLm5XlJDY)

We design a simple web app by using flutter, it has only a menu and some text on left side also a background image.

### Food App flutter web Final UI

![App UI](./Flutter%20Web.png)
